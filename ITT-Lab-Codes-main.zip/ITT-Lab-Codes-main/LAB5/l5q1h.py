a = {1, 2, 3, 4, 5, 6}

b = {1, 2, 3, 7}

print(a.union(b))
print(a.intersection(b))
print(a.difference(b))

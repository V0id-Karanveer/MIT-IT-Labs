decimal = int(input("Enter the number in decimal: "))

print(bin(decimal))
print(oct(decimal))
print(hex(decimal))

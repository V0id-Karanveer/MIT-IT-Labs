import re
s = "Hello Everyone! Thank you so much for visting."
print(re.sub("so", "very", s))